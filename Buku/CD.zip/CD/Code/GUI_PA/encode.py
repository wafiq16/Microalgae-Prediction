txt = "085608005729"
print(txt.encode(encoding="ITU-T", errors="ignore"))
